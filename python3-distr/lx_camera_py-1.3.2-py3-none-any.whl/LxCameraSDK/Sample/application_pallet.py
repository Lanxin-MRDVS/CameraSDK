import json
import time
from LxCameraSDK import *
from utils import check_state


def demo_application_pallet():
    # initialize camera
    camera = LxCamera("../../libLxCameraApi.so")
    state = camera.DcSetInfoOutput(0, False, "./")
    check_state(camera, state)
    print('Camera API Version: {}'.format(camera.DcGetApiVersion()))

    # search devices
    device_list = camera.DcGetDeviceList()
    if len(device_list) < 1:
        print('No camera device found')
        exit(-1)
    else:
        print(f'Found {len(device_list)} devices')

    # open devices
    open_mode = LX_OPEN_MODE.OPEN_BY_IP
    open_param = "0"
    if open_mode == LX_OPEN_MODE.OPEN_BY_IP:
        open_param = "192.168.100.120"
    elif LX_OPEN_MODE.OPEN_BY_ID:
        open_param = "F13301122647"
    else:
        pass
    state, handle, device_info = camera.DcOpenDevice(open_mode, open_param)
    check_state(camera, state, handle)

    print(f"DcOpenDevice success, device_info:\n"
          f"camera_id: {device_info.id}\n"
          f"unique_id: {handle}\n"
          f"camera_ip: {device_info.ip}\n"
          f"firmware_ver: {device_info.firmware_ver}\n"
          f"camera_sn: {device_info.sn}\n"
          f"camera_name: {device_info.name}\n"
          f"img_algorithm_ver: {device_info.algor_ver}")

    # check current algo
    algor_mode = 0
    state, value = camera.DcGetIntValue(handle, LX_CAMERA_FEATURE.LX_INT_ALGORITHM_MODE)
    check_state(camera, state, handle)
    print(f'Current mode: {value}')

    # switch to avoid obstacle mode, MODE_AVOID_OBSTACLE for old device, MODE_AVOID_OBSTACLE2 for new device (recommanded)
    algor_mode = LX_ALGORITHM_MODE.MODE_PALLET_LOCATE
    state = camera.DcSetIntValue(handle, LX_CAMERA_FEATURE.LX_INT_ALGORITHM_MODE, algor_mode)
    check_state(camera, state, handle)

    # get algo version
    state, value = camera.DcGetStringValue(handle, LX_CAMERA_FEATURE.LX_STRING_ALGORITHM_VERSION)
    check_state(camera, state, handle)
    print(f"Current algo version: {value}")

    # get algo param
    state, value = camera.DcGetStringValue(handle, LX_CAMERA_FEATURE.LX_STRING_ALGORITHM_PARAMS)
    check_state(camera, state, handle)
    print(f"Current algo json param: {value}")
    current_json_param = json.loads(value)

    # modify algo param
    # current_json_param["max_leg"] = 171
    state = camera.DcSetStringValue(handle, LX_CAMERA_FEATURE.LX_STRING_ALGORITHM_PARAMS, json.dumps(current_json_param))
    check_state(camera, state, handle)

    # set algo to none_stop_mode
    state = camera.DcSetIntValue(handle, LX_CAMERA_FEATURE.LX_INT_WORK_MODE, 1)
    check_state(camera, state, handle)

    # set streams

    # amp stream
    enable_amp = True
    state = camera.DcSetBoolValue(handle, LX_CAMERA_FEATURE.LX_BOOL_ENABLE_3D_AMP_STREAM, enable_amp)
    check_state(camera, state, handle)
    print('DcSetBoolValue success, cmd: LX_BOOL_ENABLE_3D_AMP_STREAM')

    # 2D stream
    state, get_rgb_enable = camera.DcGetBoolValue(handle, LX_CAMERA_FEATURE.LX_BOOL_ENABLE_2D_STREAM)
    check_state(camera, state, handle)
    print(f'DcGetBoolValue success, cmd: LX_BOOL_ENABLE_2D_STREAM, get_2d_enable: {get_rgb_enable}')

    # 3D stream
    state, get_depth_enable = camera.DcGetBoolValue(handle, LX_CAMERA_FEATURE.LX_BOOL_ENABLE_3D_DEPTH_STREAM)
    check_state(camera, state, handle)
    print(f'DcGetBoolValue success, cmd: LX_BOOL_ENABLE_3D_DEPTH_STREAM, depth_enable: {get_depth_enable}')

    state = camera.DcStartStream(handle)
    check_state(camera, state, handle)

    # main loop
    while True:
        state, _ = camera.getFrame(handle)
        if state != LX_STATE.LX_SUCCESS:
            if state != LX_STATE.LX_E_FRAME_ID_NOT_MATCH or state != LX_STATE.LX_E_FRAME_MULTI_MACHINE:
                print("DcSetCmd LX_CMD_GET_NEW_FRAME failed!")
                if state == LX_STATE.LX_E_RECONNECTING:
                    print("Device is reconnecting!")
                time.sleep(1)
                continue

        state, result = camera.getAlgorithmStatus(handle)
        print(result.x, result.y, result.yaw)
    camera.DcStopStream(handle)
    camera.DcCloseDevice(handle)

if __name__ == '__main__':
    demo_application_pallet()
