import cv2
import numpy as np
from LxCameraSDK import LX_STATE, LxCamera, DcHandle


def visualize(image):
    image = cv2.normalize(image, None, 0, 255, cv2.NORM_MINMAX)
    image = np.uint8(image)
    image = cv2.applyColorMap(image, cv2.COLORMAP_JET)
    return image


def check_state(camera: LxCamera, state: LX_STATE, handle: DcHandle = None):
    if state != LX_STATE.LX_SUCCESS:
        if state == LX_STATE.LX_E_RECONNECTING:
            print('device reconnecting')
        else:
            print(camera.DcGetErrorString(state))
            if handle is not None:
                camera.DcCloseDevice(handle)
            exit(1)
