from enum import Enum, auto
from ctypes import Structure, c_float, c_int, c_double, c_uint8, c_uint64, c_int32, c_int64, c_char, c_uint32, POINTER, cast


class LxGroundPlane(Structure):
    _fields_ = [
        ('a', c_float),
        ('b', c_float),
        ('c', c_float),
        ('d', c_float),
    ]

    def __repr__(self):
        return f'a = {self.a}, b = {self.b}, c = {self.c}, d = {self.d}'


class LxPoint2d(Structure):
    _fields_ = [
        ('x', c_float),
        ('y', c_float),
    ]

    def __repr__(self):
        return f'x = {self.x}, y = {self.y}'


class LxPoint3dWithRGB(Structure):
    _fields_ = [
        ('x', c_float),
        ('y', c_float),
        ('z', c_float),
        ('r', c_uint8),
        ('g', c_uint8),
        ('b', c_uint8),
    ]

    def __repr__(self):
        return f'x = {self.x}, y = {self.y}, z = {self.z}, r = {self.r}, g = {self.g}, b = {self.b}'


class LxVelocity(Structure):
    _fields_ = [
        ('linear', c_float * 3),
        ('angular', c_float * 3),
    ]


LxRotation = c_float * 9
LxTranslation = c_float * 3


class LxPose(Structure):
    _fields_ = [
        ('R', LxRotation),
        ('T', LxTranslation),
        ('timestamp', c_uint64)
    ]


class LxObstacleBox(Structure):
    _fields_ = [
        ('pose', LxPose),
        ('width', c_float),
        ('height', c_float),
        ('depth', c_float),
        ('center', LxTranslation),
        ('type', c_int32),
        ('id', c_int64),
        ('velocity', LxVelocity)
    ]


class LxObstacleBoxN(Structure):
    _fields_ = [
        ('pose', LxPose),
        ('width', c_float),
        ('height', c_float),
        ('depth', c_float),
        ('center', LxTranslation),
        ('type_idx', c_int32),
        ('id', c_int64),
        ('prev_id', c_int64),
        ('box_2d_x_min', c_float),
        ('box_2d_y_min', c_float),
        ('box_2d_x_max', c_float),
        ('box_2d_y_max', c_float),
        ('velocity', LxVelocity),
        ('type_name_len', c_int32),
        ('type_name', c_char * 512),
        ('reserved', c_char * 1024)
    ]


class LxAvState(Enum):
    LxAvSuccess =                    0
    LxAvGroundPriorNotSet =         -1
    LxAvInputNotSet =               -2
    LxAvNoPointInRange =            -3
    LxAvNoPointAfterFilterGround =  -4
    LxAvNoPointAfterRadiusFilter =  -5
    LxAvObstaclesNotSegmented =     -6
    LxAvUndefinedError =            -99


class LxAvoidanceOutput(Structure):
    _fields_ = [
        ('state', c_int),
        ('groundPlane', LxGroundPlane),
        ('number_3d', c_uint32),
        ('cloud_output', POINTER(LxPoint3dWithRGB)),
        ('number_box', c_uint32),
        ('obstacleBoxs', POINTER(LxObstacleBox)),
    ]


class LxAvoidanceOutputN(Structure):
    _fields_ = [
        ('state', c_int),
        ('groundPlane', LxGroundPlane),
        ('number_3d', c_uint32),
        ('cloud_output', POINTER(LxPoint3dWithRGB)),
        ('number_box', c_uint32),
        ('obstacleBoxes', POINTER(LxObstacleBoxN)),
        ('resveredData', c_char * 4096)
    ]


class LxPalletPose(Structure):
    _fields_ = [
        ('return_val', c_int),
        ('x', c_float),
        ('y', c_float),
        ('yaw', c_float),
        ('extents', c_int * 8192)
    ]


class LxRelocPose(Structure):
    _fields_ = [
        ('x', c_double),
        ('y', c_double),
        ('theta', c_double),
    ]


class LxOdomData(Structure):
    _fields_ = [
        ('timestamp', c_int64),
        ('x', c_double),
        ('y', c_double),
        ('theta', c_double),
    ]


def genLxLaserWithRange(range_start, range_end):
    num_ele = range_end - range_start
    assert num_ele > 0
    range_ = (c_float * num_ele)(0)
    for i in range(num_ele):
        range_[i] = float(i)
    laser_data = LxLaser()
    laser_data.ranges = cast(range_, POINTER(c_float))
    laser_data.range_size = num_ele
    return laser_data

class LxLaser(Structure):
    _fields_ = [
        ('timestamp', c_int64),
        ('time_increment', c_float),
        ('angle_min', c_float),
        ('angle_max', c_float),
        ('angle_increment', c_float),
        ('range_min', c_float),
        ('range_max', c_float),
        ('reserved', c_float),
        ('range_size', c_float),
        ('ranges', POINTER(c_float)),
    ]


class LxLaserPose(Structure):
    _fields_ = [
        ('timestamp', c_int64),
        ('x', c_double),
        ('y', c_double),
        ('theta', c_double),
    ]


class LxLocation(Structure):
    _fields_ = [
        ('timestamp', c_int64),
        ('status', c_int32),
        ('x', c_double),
        ('y', c_double),
        ('theta', c_double),
        ('extents', c_int32 * 8192)
    ]

