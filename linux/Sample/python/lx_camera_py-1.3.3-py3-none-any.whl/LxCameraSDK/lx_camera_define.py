import numpy as np
from enum import Enum, auto
from ctypes import (c_ulonglong, c_char, Structure, c_bool, c_int, c_float, c_void_p, c_uint,
                    CFUNCTYPE, POINTER, c_uint8, c_uint16, c_uint32, c_int16)


class LX_STATE(Enum):
    LX_SUCCESS =                      0   # success
    LX_ERROR =                       -1   # Unknown errors
    LX_E_NOT_SUPPORT =               -2   # The feature is not supported
    LX_E_NETWORK_ERROR =             -3   # Network communication error
    LX_E_INPUT_ILLEGAL =             -4   # Parameters are illegal
    LX_E_RECONNECTING =              -5   # Device reconnecting
    LX_E_DEVICE_ERROR =              -6   # Device error
    LX_E_DEVICE_NEED_UPDATE =        -7   # The device version is too low and needs to be upgraded
    LX_E_API_NEED_UPDATE =           -8   # API version too low
    LX_E_CTRL_PERMISS_ERROR =        -9   # Exclusive control fails
    LX_E_GET_DEVICEINFO_ERROR =      -10  # Failed to get device information
    LX_E_IMAGE_SIZE_ERROR =          -11  # The image size does not match and needs to be reopened
    LX_E_IMAGE_PARTITION_ERROR =     -12  # Image parsing failed, try reopening it
    LX_E_DEVICE_NOT_CONNECTED =      -13  # The camera is not connected
    LX_E_DEVICE_INIT_FAILED =        -14  # Camera initialization failed
    LX_E_DEVICE_NOT_FOUND =          -15  # Camera not found
    LX_E_FILE_INVALID =              -16  # File error, incorrect file name or type format or file open failure
    LX_E_CRC_CHECK_FAILED =          -17  # File CRD or MD5 checksum failure
    LX_E_TIME_OUT =                  -18  # Timeout
    LX_E_FRAME_LOSS =                -19  # Missing frames
    LX_E_ENABLE_ANYSTREAM_FAILED =   -20  # Failed to open any stream
    LX_E_NOT_RECEIVE_STREAM =        -21  # No data stream received
    LX_E_PARSE_STREAM_FAILED =       -22  # Starting the stream succeeded but parsing the stream data failed
    LX_E_PROCESS_IMAGE_FAILED =      -23  # Image computation processing failed
    LX_E_SETTING_NOT_ALLOWED =       -24  # Setting is not allowed in normally open mode
    LX_E_LOAD_DATAPROCESSLIB_ERROR = -25  # Error loading image processing algorithm library
    LX_E_FUNCTION_CALL_LOGIC_ERROR = -26  # Function call logic error
    LX_E_IPAPPDR_UNREACHABLE_ERROR = -27  # IP is unreachable or the network is misconfigured
    LX_E_FRAME_ID_NOT_MATCH        = -28  # Timeout range frame desynchronization error
    LX_E_FRAME_MULTI_MACHINE       = -29  # Multi-device interference signals are detected in the frame
    LX_W_LOAD_DATAPROCESSLIB_ERROR =  25  # Failure to load image processing algorithm library does not affect other functions


error_info = {
    LX_STATE.LX_SUCCESS: "Functions normally",
    LX_STATE.LX_ERROR: "Unknown errors",
    LX_STATE.LX_E_NOT_SUPPORT: "The feature is not supported",
    LX_STATE.LX_E_NETWORK_ERROR: "Network communication error",
    LX_STATE.LX_E_INPUT_ILLEGAL: "Parameters are illegal",
    LX_STATE.LX_E_RECONNECTING: "Device reconnecting",
    LX_STATE.LX_E_DEVICE_ERROR: "Device error",
    LX_STATE.LX_E_DEVICE_NEED_UPDATE: "The device version is too low and needs to be upgraded",
    LX_STATE.LX_E_API_NEED_UPDATE: "API version too low",
    LX_STATE.LX_E_CTRL_PERMISS_ERROR: "Exclusive control fails",
    LX_STATE.LX_E_GET_DEVICEINFO_ERROR: "Failed to get device information",
    LX_STATE.LX_E_IMAGE_SIZE_ERROR: "The image size does not match and needs to be reopened",
    LX_STATE.LX_E_IMAGE_PARTITION_ERROR: "Image parsing failed, try reopening it",
    LX_STATE.LX_E_DEVICE_NOT_CONNECTED: "The camera is not connected",
    LX_STATE.LX_E_DEVICE_INIT_FAILED: "Camera initialization failed",
    LX_STATE.LX_E_DEVICE_NOT_FOUND: "Camera not found",
    LX_STATE.LX_E_FILE_INVALID: "File error, incorrect file name or type format or file open failure",
    LX_STATE.LX_E_CRC_CHECK_FAILED: "File CRD or MD5 checksum failure",
    LX_STATE.LX_E_TIME_OUT: "Timeout",
    LX_STATE.LX_E_FRAME_LOSS: "Missing frames",
    LX_STATE.LX_E_ENABLE_ANYSTREAM_FAILED: "Failed to open any stream",
    LX_STATE.LX_E_NOT_RECEIVE_STREAM: "No data stream received",
    LX_STATE.LX_E_PARSE_STREAM_FAILED: "Starting the stream succeeded but parsing the stream data failed",
    LX_STATE.LX_E_PROCESS_IMAGE_FAILED: "Image computation processing failed",
    LX_STATE.LX_E_SETTING_NOT_ALLOWED: "Setting is not allowed in normally open mode",
    LX_STATE.LX_E_LOAD_DATAPROCESSLIB_ERROR: "Error loading image processing algorithm library",
    LX_STATE.LX_E_FUNCTION_CALL_LOGIC_ERROR: "Function call logic error",
    LX_STATE.LX_E_IPAPPDR_UNREACHABLE_ERROR: "IP is unreachable or the network is misconfigured",
    LX_STATE.LX_E_FRAME_ID_NOT_MATCH: "Timeout range frame desynchronization error",
    LX_STATE.LX_E_FRAME_MULTI_MACHINE: "Multi-device interference signals are detected in the frame",
    LX_STATE.LX_W_LOAD_DATAPROCESSLIB_ERROR: "Failure to load image processing algorithm library does not affect other functions"
}


# LX_API = LX_STATE
# DcHandle = c_ulonglong
class DcHandle(Structure):
    _fields_ = [
        ("handle", c_ulonglong)
    ]

    def __repr__(self):
        return f'handle: {self.handle}'


c_char32 = c_char * 32


# 设备型号
class LX_DEVICE_TYPE(Enum):
    LX_DEVICE_M2 =        1001
    LX_DEVICE_M3 =        auto()
    LX_DEVICE_M4Pro =     auto()
    LX_DEVICE_M4_MEGA =   auto()
    LX_DEVICE_M4 =        auto()
    LX_DEVICE_M4V1_1 =    1006
    LX_DEVICE_M4ProV1_1 = 1007 

    LX_DEVICE_S1 =        2001
    LX_DEVICE_S2 =        auto()
    LX_DEVICE_S2MaxV1 =   auto()
    LX_DEVICE_S2MaxV2 =   auto()
    LX_DEVICE_S2MaxV1_1 = 2005
    LX_DEVICE_S3 =        2101

    LX_DEVICE_I1 =        3001
    LX_DEVICE_I2 =        auto()
    LX_DEVICE_T1 =        4001
    LX_DEVICE_T2 =        auto()
    LX_DEVICE_H3 =        5001
    LX_DEVICE_V1Pro =     6001

    LX_DEVICE_NULL =      0


# Broad category of device, not used at this time
class LX_DEVICE_SERIALS(Enum):
    LX_SERIAL_GIGE =       1
    LX_SERIAL_WK =         auto()
    LX_SERIAL_OTHER =      auto()
    LX_SERIAL_ALL =        auto()
    LX_SERIAL_LOCAL_LOOP = auto()  # Local loopback (used to distinguish between cases where the SDK and camera-side programs are running on the same host)


# Device Details
class LxDeviceInfo(Structure):
    _fields_ = [
        ('handle', DcHandle),                 # Device Unique Identification
        ('dev_type', c_int),                  # Device type
        ('id', c_char32),                     # Device id
        ('ip', c_char32),                     # Device ip:port
        ('sn', c_char32),                     # Device Serial Number
        ('mac', c_char32),                    # Device mac address
        ('firmware_ver', c_char32),           # Device software version number
        ('algor_ver', c_char32),              # Device algorithm version number
        ('name', c_char32),                   # Device name, e.g. camera_M3_192.168.11.13_9803
        ('reserve', c_char32),                # Reserved field, subnet mask # add at 20231120
        ('reserve2', c_char32),               # Reserved field 2, gateway ip # add at 20231120
        ('reserve3', c_char * 64),            # Reserved field 3
        ('reserve4', c_char * 128)            # Reserved field 4
    ]

    def __repr__(self):
        return (f'handle: {self.handle}, dev_type: {self.dev_type}, id: {self.id.decode("utf-8")}, ip: {self.ip.decode("utf-8")}, '
                f'sn: {self.sn.decode("utf-8")}, mac: {self.mac.decode("utf-8")}, firmware_ver: {self.firmware_ver.decode("utf-8")}, '
                f'algor_ver: {self.algor_ver.decode("utf-8")}, name: {self.name.decode("utf-8")}')


class LxIntValueInfo(Structure):
    _fields_ = [
        ('set_available', c_bool),  # Whether the current value is settable, true - settable, false - not settable
        ('cur_value', c_int),       # current value
        ('max_value', c_int),       # max value
        ('min_value', c_int),       # min value
        ('reserve', c_int * 4)      # Reserved field
    ]

    def __repr__(self):
        return f'set_available: {self.set_available}, cur_value: {self.cur_value}, max_value: {self.max_value}, min_value: {self.min_value}'


class LxFloatValueInfo(Structure):
    _fields_ = [
        ('set_available', c_bool),
        ('cur_value', c_float),
        ('max_value', c_float),
        ('min_value', c_float),
        ('reserve', c_float * 4)
    ]

    def __repr__(self):
        return f'set_available: {self.set_available}, cur_value: {self.cur_value}, max_value: {self.max_value}, min_value: {self.min_value}'


# Camera open mode
class LX_OPEN_MODE(Enum):
    OPEN_BY_INDEX = 0
    OPEN_BY_IP =    1
    OPEN_BY_SN =    2
    OPEN_BY_ID =    3


# 3D intensity maps and depth maps have different data formats, and you need to use the corresponding feature to get the data pointer.
class LX_DATA_TYPE(Enum):
    LX_DATA_UNSIGNED_CHAR =  0
    LX_DATA_UNSIGNED_SHORT = 2
    LX_DATA_SIGNED_SHORT =   3
    LX_DATA_FLOAT =          5
    LX_DATA_OBSTACLE =       16
    LX_DATA_PALLET =         17
    LX_DATA_LOCATION =       18
    LX_DATA_OBSTACLE2 =      19


LX_DATA_TYPE_TO_CTYPES = {
    LX_DATA_TYPE.LX_DATA_UNSIGNED_CHAR: c_uint8,
    LX_DATA_TYPE.LX_DATA_UNSIGNED_SHORT: c_uint16,
    LX_DATA_TYPE.LX_DATA_SIGNED_SHORT: c_int16,
    LX_DATA_TYPE.LX_DATA_FLOAT: c_uint32
}


#  Image Binning Mode
class LX_BINNING_MODE(Enum):
    LX_BINNING_1X1 = 0
    LX_BINNING_2X2 = 1
    LX_BINNING_4X4 = 2


# Structured Light Camera Encoding Methods
class LX_STRUCT_LIGHT_CODE_MODE(Enum):
    LX_CODE_NORMAL =  1  # common
    LX_CODE_STATBLE = 2  # stabilise
    LX_CODE_ENHANCE = 3  # High Precision Reinforcement


# Camera built-in algorithms
class LX_ALGORITHM_MODE(Enum):
    MODE_ALL_OFF =         0  # Disable built-in obstacle avoidance algorithms
    MODE_AVOID_OBSTACLE =  1  # Built-in obstacle avoidance algorithm
    MODE_PALLET_LOCATE =   2  # Built-in pallet docking algorithm
    MODE_VISION_LOCATION = 3  # Built-in visual localization algorithm
    MODE_AVOID_OBSTACLE2 = 4  # Built-in obstacle avoidance algorithm V2


# Camera working modes
class LX_CAMERA_WORK_MODE(Enum):
    KEEP_HEARTBEAT = 0  # Maintain heartbeat, camera auto standby after SDK heartbeat interruption
    WORK_FOREVER =   1  # Always keep working, some parameters can not be set at this time


# Camera Trigger Mode
class LX_TRIGGER_MODE(Enum):
    LX_TRIGGER_MODE_OFF =      0  # Trigger Mode Off, Streaming Mode, Default
    LX_TRIGGER_SOFTWARE = auto()  # soft-trigger mode
    LX_TRIGGER_HARDWARE = auto()  # hard-trigger mode


# IO Operating Mode
class LX_IO_WORK_MODE(Enum):
    ALGORITHM_IO_MODE = 0  # IO as input and output for built-in application algorithms
    USER_IO_MODE =      1  # The user can control the IO state by himself, refer to LX_IO_OUT_USERCTRL_MODE
    TRIGGER_IO_MODE =   2  # IO as trigger signal output, valid only in trigger mode


# Customizing IO output states
class LX_IO_OUTPUT_STATE(Enum):
    OUT1_0_OUT2_0 = 0
    OUT1_0_OUT2_1 = 1
    OUT1_1_OUT2_0 = 2
    OUT1_1_OUT2_1 = 3


# Filter Setting Mode
class LX_FILTER_MODE(Enum):
    FILTER_SIMPLE = 1
    FILTER_NORMAL = 2
    FILTER_EXPERT = 3


class LX_3D_FREQ_MODE(Enum):
    FREQ_SINGLE_3D = 0
    FREQ_DUAL_3D =   1
    FREQ_TRIPLE_3D = 2


class LX_RGBD_ALIGN_MODE(Enum):
    RGBD_ALIGN_OFF = 0
    DEPTH_TO_RGB =   1
    RGB_TO_DEPTH =   2


class LX_CAN_PROTOCOL_TYPE(Enum):
    CAN_MRDVS =  0
    CAN_KECONG = 1


# Image Display Related Information
class FrameDataInfo(Structure):
    _fields_ = [
        ('frame_data_type', c_int),
        ('frame_width', c_int),
        ('frame_height', c_int),
        ('frame_channel', c_int),
        ('frame_data', c_void_p),
        ('sensor_timestamp', c_ulonglong),   # Sensor out of the image timestamp
        ('recv_timestamp', c_ulonglong),     # Timestamp when frame data is received
    ]

    def __repr__(self):
        return (f'frame_data_type: {self.frame_data_type}, frame_width: {self.frame_width}, frame_height: {self.frame_height}, '
                f'frame_channel: {self.frame_channel}, sensor_timestamp: {self.sensor_timestamp}, recv_timestamp: {self.recv_timestamp}')


class ImageIntricParam(Structure):
    _fields_ = [
        ('fx', c_float),
        ('fy', c_float),
        ('cx', c_float),
        ('cy', c_float),
        ('d1', c_float),
        ('d2', c_float),
        ('d3', c_float),
        ('d4', c_float),
        ('d5', c_float),
    ]

    def __repr__(self):
        return f'fx: {self.fx}, fy: {self.fy}, cx: {self.cx}, cy: {self.cy}, d1: {self.d1}, d2: {self.d2}, d3: {self.d3}, d4: {self.d4}, d5: {self.d5}'


class Image3DExtricParam(Structure):
    _fields_ = [
        ('r0', c_float),
        ('r1', c_float),
        ('r2', c_float),
        ('r3', c_float),
        ('r4', c_float),
        ('r5', c_float),
        ('r6', c_float),
        ('r7', c_float),
        ('r8', c_float),
        ('t0', c_float),
        ('t1', c_float),
        ('t2', c_float),
    ]

    def __repr__(self):
        translation_matrix = np.zeros([4, 3], dtype=np.float32)
        translation_matrix[0][0] = self.r0
        translation_matrix[0][1] = self.r1
        translation_matrix[0][2] = self.r2
        translation_matrix[1][0] = self.r3
        translation_matrix[1][1] = self.r4
        translation_matrix[1][2] = self.r5
        translation_matrix[2][0] = self.r6
        translation_matrix[2][1] = self.r7
        translation_matrix[2][2] = self.r8
        translation_matrix[0][3] = self.t0
        translation_matrix[1][3] = self.t1
        translation_matrix[2][3] = self.t2
        return translation_matrix


# Data frame specific information
class FrameInfo(Structure):
    _fields_ = [
        ('frame_state', c_int),
        ('handle', DcHandle),
        ('depth_data', FrameDataInfo),
        ('amp_data', FrameDataInfo),
        ('rgb_data', FrameDataInfo),
        ('app_data', FrameDataInfo),       # Algorithm output results
        ('reserve_data', c_void_p)
    ]

    def __repr__(self):
        return f'frame_state: {self.frame_state}, handle: {self.handle}'


class FrameExtendInfo(Structure):
    _fields_ = [
        ('depth_frame_id', c_uint),
        ('amp_frame_id', c_uint),
        ('rgb_frame_id', c_uint),
        ('app_frame_id', c_uint),
        ('reserve_data1', c_void_p),
        ('reserve_data2', c_void_p),
        ('reserve_data3', c_void_p),
    ]


# Current status of the camera
class LX_CAMERA_STATUS(Enum):
    STATUS_CLOSED =               0  # Camera not turned on or off status
    STATUS_OPENED_UNSTARTED =     1  # Camera on but not streaming
    STATUS_STARTED =              2  # Camera on and streaming
    STATUS_CONNECTING =           3  # Camera disconnected and reconnecting
    STATUS_CONNECT_SUCCESS =      4  # Camera reconnected successfully


# Camera status callback information
class CameraStatus(Structure):
    _fields_ = [
        ('camera_state', c_int),
        ('status_time', c_ulonglong),
        ('reserve_data', c_void_p)
    ]


LX_FRAME_CALLBACK = CFUNCTYPE(None, POINTER(FrameInfo), c_void_p)

LX_CAMERA_STATUS_CALLBACK = CFUNCTYPE(None, POINTER(CameraStatus))


class LX_CAMERA_FEATURE(Enum):
    # int feature
    LX_INT_FIRST_EXPOSURE =   1001   # 默认高积分曝光值，单位us, 针对多积分情况为第一个积分的曝光时间
    LX_INT_SECOND_EXPOSURE =  1002   # 默认低积分曝光值，单位us, 针对多积分情况为第二个积分的曝光时间
    LX_INT_THIRD_EXPOSURE =   1003   # 针对多积分情况为第三个积分的曝光时间，单位us
    LX_INT_FOURTH_EXPOSURE =  1004   # 针对多积分情况为第四个积分的曝光时间，单位us
    LX_INT_GAIN =             1005   # 增益，与曝光效果等价。会引入噪声，可适当调节增益防止曝光参数过大

    LX_INT_MIN_DEPTH =        1011    # 最小深度值
    LX_INT_MAX_DEPTH =        1012    # 最大深度值
    LX_INT_MIN_AMPLITUDE =    1013    # 有效信号最小强度值
    LX_INT_MAX_AMPLITUDE =    1014    # 有效信号最大强度值
    LX_INT_CODE_MODE =        1016    # 结构光相机编码模式，参考LX_STRUCT_LIGHT_CODE_MODE
    LX_INT_WORK_MODE =        1018    # 工作模式，参考LX_CAMERA_WORK_MODE
    LX_INT_LINK_SPEED =       1019    # 协商的网卡网速 100-百兆，1000-千兆, 只支持获取，不可设置

    # 3D图像参数
    LX_INT_3D_IMAGE_WIDTH =     1021  # 3D图像分辨率宽度,(ROI/Binning/2D对齐后会变化,需重新获取)
    LX_INT_3D_IMAGE_HEIGHT =    1022  # 3D图像分辨率高度,(ROI/Binning/2D对齐后会变化,需重新获取)
    LX_INT_3D_IMAGE_OFFSET_X =  1023  # ROI水平偏移像素，ROI设置中WIDTH HEIGHT OFFSET_X OFFSET_Y一起设置, 设置参数请用DcSetROI
    LX_INT_3D_IMAGE_OFFSET_Y =  1024  # ROI垂直偏移像素，ROI设置中WIDTH HEIGHT OFFSET_X OFFSET_Y一起设置, 设置参数请用DcSetROI
    LX_INT_3D_BINNING_MODE =    1025  # 3D图像binning，参考LX_BINNING_MODE
    LX_INT_3D_DEPTH_DATA_TYPE = 1026  # 深度图像数据格式，只能获取，对应的值参考LX_DATA_TYPE
    LX_INT_3D_FREQ_MODE =       1027  # 3D频率模式,详见LX_3D_FREQ_MODE定义

    # 3D强度图像，尺寸与3D深度图一致
    LX_INT_3D_AMPLITUDE_CHANNEL =   1031  # 3D强度图像通道数，与深度图通道共用,单色为1，彩色为3
    LX_INT_3D_AMPLITUDE_DATA_TYPE = 1035  # 强度图像数据格式，只能获取，对应的值参考LX_DATA_TYPE
    LX_INT_3D_AUTO_EXPOSURE_LEVEL = 1036  # 3D自动曝光开启时的曝光等级,期间不允许设置曝光值与增益
    LX_INT_3D_AUTO_EXPOSURE_MAX =   1037  # 3D自动曝光上限值
    LX_INT_3D_AUTO_EXPOSURE_MIN =   1038  # 3D自动曝光下限值

    # 2D图像
    LX_INT_2D_IMAGE_WIDTH =     1041    # 2D图像分辨率宽度,(ROI或Binning后会变化)
    LX_INT_2D_IMAGE_HEIGHT =    1042    # 2D图像分辨率高度,(ROI或Binning后会变化)
    LX_INT_2D_IMAGE_OFFSET_X =  1043    # 2D图像ROI水平偏移像素，ROI设置中WIDTH HEIGHT OFFSET_X OFFSET_Y一起设置, 设置参数请用DcSetROI
    LX_INT_2D_IMAGE_OFFSET_Y =  1044    # 2D图像ROI垂直偏移像素，ROI设置中WIDTH HEIGHT OFFSET_X OFFSET_Y一起设置, 设置参数请用DcSetROI
    LX_INT_2D_BINNING_MODE =    1045    # 2D图像binning，参考LX_BINNING_MODE
    LX_INT_2D_IMAGE_CHANNEL =   1046    # 2D图像通道数，单色为1，彩色为3
    LX_INT_2D_IMAGE_DATA_TYPE = 1047    # 2D图像数据格式，只能获取,对应的值参考LX_DATA_TYPE

    LX_INT_2D_MANUAL_EXPOSURE =     1051  # 2D手动曝光时的曝光值
    LX_INT_2D_MANUAL_GAIN =         1052  # 2D手动曝光时的增益值
    LX_INT_2D_AUTO_EXPOSURE_LEVEL = 1054  # 2D图像自动曝光时曝光等级[0-100], 0-整体更暗， 100-整体更亮

    LX_INT_TOF_GLOBAL_OFFSET =  1061  # TOF深度数据偏移
    LX_INT_3D_UNDISTORT_SCALE = 1062  # 3D图像反畸变系数，[0,100]，值越大，保留数据越多，但是边缘会有黑色填充
    LX_INT_2D_UNDISTORT_SCALE = 1520  # 2D图像反畸变系数，[0,100]，值越大，保留数据越多，但是边缘会有黑色填充
    LX_INT_ALGORITHM_MODE =     1065  # 设置内置应用算法, 部分型号支持,对应的值参考LX_ALGORITHM_MODE
                                      # 算法上移时（LX_INT_CALCULATE_UP），不允许开启内置应用算法
    LX_INT_MODBUS_ADDR =        1066  # modbus地址，部分型号支持MODBUS协议通过串口输出
    LX_INT_HEART_TIME =         1067  # 与设备间心跳时间,单位ms
    LX_INT_GVSP_PACKET_SIZE =   1068  # GVSP单包数据分包大小, 单位字节
    LX_INT_CALCULATE_UP =       1070  # 允许tof或rgb算法上下移，节省上位机或相机算力，可能影响帧率和延时
                                      # 0-0xFFFF，四个F代表意义：保留位，滤波上移，RGB上移，TOF上移
                                      # 内置应用算法（LX_INT_ALGORITHM_MODE）开启时不允许上移
    LX_INT_CAN_BAUD_RATE =     1072  # can的波特率值, 单位bps
    LX_INT_CAN_NODE_ID =       1073  # can地址
    LX_INT_CAN_PROTOCOL_TYPE = 1074  # can协议类型, 参考枚举LX_CAN_PROTOCOL_TYPE
    LX_INT_SAVE_PARAMS_GROUP = 1075  # 将相机当前配置保存为指定的参数组
    LX_INT_LOAD_PARAMS_GROUP = 1076  # 一键加载指定索引的参数组
    LX_INT_RGBD_ALIGN_MODE =   1077  # rgbd对齐的方式，参考LX_RGBD_ALIGN_MODE，替代LX_BOOL_ENABLE_2D_TO_DEPTH

    LX_INT_TRIGGER_MODE =                 1069  # 触发模式,对应的值参考LX_TRIGGER_MODE
    LX_INT_HARDWARE_TRIGGER_FILTER_TIME = 1085  # 硬触发滤波时间, 单位us
    LX_INT_TRIGGER_MIN_PERIOD_TIME =      1086  # 触发最小时间间隔, 单位us
    LX_INT_TRIGGER_DELAY_TIME =           1087  # 触发延迟时间,单位us
    LX_INT_TRIGGER_FRAME_COUNT =          1088  # 单次触发帧数
    LX_INT_IO_WORK_MODE =                 1530  # GPIO信号输出控制模式, 参考LX_IO_WORK_MODE
    LX_INT_IO_OUTPUT_STATE =              1531  # GPIO信号输出的用户控制模式, 参考LX_IO_OUTPUT_STATE

    LX_INT_FILTER_MODE =              1090  # 滤波模式,参考LX_FILTER_MODE
    LX_INT_FILTER_SMOOTH_LEVEL =      1091  # 当LX_INT_FILTER_MODE为FILTER_NORMAL时,可设置滤波平滑等级，[0, 3]，值越大，滤波越强
    LX_INT_FILTER_NOISE_LEVEL =       1092  # 当LX_INT_FILTER_MODE为FILTER_NORMAL时,可设置滤波噪声等级，[0, 3]，值越大，滤波越强
    LX_INT_FILTER_TIME_LEVEL =        1093  # 当LX_INT_FILTER_MODE为FILTER_NORMAL时,可设置滤波时域等级，[0, 3]，值越大，滤波越强
    LX_INT_FILTER_DETECT_LOW_SIGNAL = 1094  # 小信号测量，可能检测到信噪比较低的数据，包括远距离数据导致多周期问题

    # float feature
    LX_FLOAT_FILTER_LEVEL =       2001   # 当LX_INT_FILTER_MODE为FILTER_SIMPLE时,可设置滤波等级，[0, 1]，值越大，滤波越强，等于0表示关闭滤波，
    LX_FLOAT_EST_OUT_EXPOSURE =   2002   # 是否评估过曝数据，[0, 1]，为1则过曝数据无效
    LX_FLOAT_LIGHT_INTENSITY =    2003   # 光强度，[0, 1]，部分型号支持
    LX_FLOAT_3D_DEPTH_FPS =       2004   # 深度图当前帧率，只可获取
    LX_FLOAT_3D_AMPLITUDE_FPS =   2005   # 强度图当前帧率，只可获取
    LX_FLOAT_2D_IMAGE_FPS =       2006   # RGB图当前帧率，只可获取
    LX_FLOAT_DEVICE_TEMPERATURE = 2007   # 相机当前温度, 只可获取

    # bool feature
    LX_BOOL_CONNECT_STATE =           3001  # 当前连接状态
    LX_BOOL_ENABLE_3D_DEPTH_STREAM =  3002  # 开启/关闭深度数据流(部分相机支持)
    LX_BOOL_ENABLE_3D_AMP_STREAM =    3003  # 开启/关闭强度数据流(部分相机支持)
    LX_BOOL_ENABLE_3D_AUTO_EXPOSURE = 3006  # 3D自动曝光使能
    LX_BOOL_ENABLE_3D_UNDISTORT =     3007  # 3D反畸变使能
    LX_BOOL_ENABLE_ANTI_FLICKER =     3008  # 抗频闪使能，LED环境照明可能导致数据存在明显波纹，部分型号支持

    LX_BOOL_ENABLE_2D_STREAM =          3011  # 开启/关闭2D数据流
    LX_BOOL_ENABLE_2D_AUTO_EXPOSURE =   3012  # 2D自动曝光使能
    LX_BOOL_ENABLE_2D_UNDISTORT =       3015  # 2D图像反畸变使能
    LX_BOOL_ENABLE_2D_TO_DEPTH =        3016  # 2D3D图像对齐使能，替换为LX_INT_RGBD_ALIGN_MODE
    LX_BOOL_ENABLE_BACKGROUND_AMP =     3017  # 强度背景光使能
    LX_BOOL_ENABLE_MULTI_MACHINE =      3018  # 多机模式使能，TOF会有多机干扰，开启此模式可以自动检测并缓解多机干扰
    LX_BOOL_ENABLE_MULTI_EXPOSURE_HDR = 3019  # HDR（多曝光高动态范围模式）使能
    LX_BOOL_ENABLE_SYNC_FRAME =         3020  # 是否开启强制帧同步, 默认数据实时性优先，若需要RGBD同步, 需要开启该模式

    # string feature
    LX_STRING_DEVICE_VERSION =          4001  # 设备版本号
    LX_STRING_FIRMWARE_NAME =           4003  # 固件文件名，用于升级设备版本，部分型号需要重新打开相机
    LX_STRING_FILTER_PARAMS =           4004  # 滤波算法参数,json格式的字符串
    LX_STRING_ALGORITHM_PARAMS =        4005  # 内置算法参数，根据当前设置的LX_ALGORITHM_MODE，返回对应的json格式字符串
    LX_STRING_ALGORITHM_VERSION =       4006  # 内置算法版本号，根据当前设置的LX_ALGORITHM_MODE，返回对应的版本号
    LX_STRING_DEVICE_OS_VERSION =       4007  # 设备系统镜像版本号
    LX_STRING_IMPORT_PARAMS_FROM_FILE = 4008  # 从本地文件加载参数到相机
    LX_STRING_EXPORT_PARAMS_TO_FILE =   4009  # 将相机当前参数导出到本地文件
    LX_STRING_CUSTOM_ID =               4010  # 客户自定义设备ID标识

    # command feature
    LX_CMD_GET_NEW_FRAME =    5001  # 主动更新当前最新数据，调用之后才可以获取相关数据指针。
                                    # 开启多个数据流时，每个数据流更新都会返回正常，除非设置LX_BOOL_ENABLE_SYNC_FRAME为true
                                    # 建议采用回调方式DcRegisterFrameCallback更新数据，此时不需调用此接口
    LX_CMD_RETURN_VERSION =   5002  # 回退上一版本
    LX_CMD_RESTART_DEVICE =   5003  # 重启相机，部分型号需要重新打开相机
    LX_CMD_WHITE_BALANCE =    5004  # 自动白平衡
    LX_CMD_RESET_PARAM =      5007  # 恢复默认参数
    LX_CMD_SOFTWARE_TRIGGER = 5008  # 软触发执行指令

    # ptr feature
    LX_PTR_2D_IMAGE_DATA =    6001  # 建议使用LX_PTR_FRAME_DATA，获取2D图像数据指针，数据长度由2D图像尺寸、通道数和数据格式（LX_INT_2D_IMAGE_DATA_TYPE）确定
    LX_PTR_3D_AMP_DATA =      6002  # 建议使用LX_PTR_FRAME_DATA，获取3D强度图数据指针，数据长度由3D图像尺寸、通道数和数据格式（LX_INT_3D_AMPLITUDE_DATA_TYPE）确定
    LX_PTR_3D_DEPTH_DATA =    6003  # 建议使用LX_PTR_FRAME_DATA，获取3D深度图数据指针，数据长度由3D图像尺寸、通道数和数据格式（LX_INT_3D_DEPTH_DATA_TYPE）确定
    LX_PTR_XYZ_DATA =         6004  # 获取点云数据指针，float*类型三通道(x, y, z为一组数据，依次循环)
                                    # 数据长度为LX_INT_3D_IMAGE_WIDTH*LX_INT_3D_IMAGE_HEIGHT*sizeof(float)*3
    LX_PTR_2D_INTRIC_PARAM =  6005  # 获取2D图像内参，float*类型指针，长度固定为9*sizeof(float)(fx,fy,cx,cy,k1,k2,p1,p2,k3)
    LX_PTR_3D_INTRIC_PARAM =  6006  # 获取3D图像内参, float*类型指针，长度固定为9*sizeof(float)(fx,fy,cx,cy,k1,k2,p1,p2,k3)
    LX_PTR_3D_EXTRIC_PARAM =  6007  # 获取3D图像外参，float*类型指针 ，长度固定为12*sizeof(float)(前9个表示旋转矩阵，后3个表示平移向量)
    LX_PTR_ALGORITHM_OUTPUT = 6008  # 建议使用LX_PTR_FRAME_DATA，获取内置算法输出
                                    # 当开启模式为MODE_AVOID_OBSTACLE，输出结果为LxAvoidanceOutput指针，参考struct LxAvoidanceOutput，
                                    # 当开启模式为MODE_PALLET_LOCATE，输出结果为LxPalletPose指针，参考struct LxPalletPose,
                                    # 当开启模式为MODE_VISION_LOCATION，输出结果为LxLocation指针，参考struct LxLocation
                                    # 当开启模式为MODE_AVOID_OBSTACLE2，输出结果为LxAvoidanceOutputN指针，参考struct LxAvoidanceOutputN
    LX_PTR_FRAME_DATA =       6009  # 获取完整一帧数据，输出结果参考结构体FrameInfo