import ctypes

import numpy as np

from LxCameraSDK import *
from utils import *


###################### TODO NOT FINISHED, DO NOT USE IT

def demo_application_location():
    # initialize camera
    camera = LxCamera("../../libLxCameraApi.so")
    state = camera.DcSetInfoOutput(0, False, "./")
    check_state(camera, state)
    print('Camera API Version: {}'.format(camera.DcGetApiVersion()))

    # search devices
    device_list = camera.DcGetDeviceList()
    if len(device_list) < 1:
        print('No camera device found')
        exit(-1)
    else:
        print(f'Found {len(device_list)} devices')

    # open devices
    open_mode = LX_OPEN_MODE.OPEN_BY_IP
    open_param = "0"
    if open_mode == LX_OPEN_MODE.OPEN_BY_IP:
        open_param = "192.168.100.83"
    elif LX_OPEN_MODE.OPEN_BY_ID:
        open_param = "F13301122647"
    else:
        pass
    state, handle, device_info = camera.DcOpenDevice(open_mode, open_param)
    check_state(camera, state, handle)

    print(f"DcOpenDevice success, device_info:\n"
          f"camera_id: {device_info.id}\n"
          f"unique_id: {handle}\n"
          f"camera_ip: {device_info.ip}\n"
          f"firmware_ver: {device_info.firmware_ver}\n"
          f"camera_sn: {device_info.sn}\n"
          f"camera_name: {device_info.name}\n"
          f"img_algorithm_ver: {device_info.algor_ver}")

    # check current algo
    algor_mode = 0
    state, value = camera.DcGetIntValue(handle, LX_CAMERA_FEATURE.LX_INT_ALGORITHM_MODE)
    check_state(camera, state, handle)
    print(f'Current mode: {value}')

    # start locating
    camera.DcSetIntValue(handle, LX_CAMERA_FEATURE.LX_INT_ALGORITHM_MODE, LX_ALGORITHM_MODE.MODE_AVOID_OBSTACLE2)


    laser_data = genLxLaserWithRange(0, 1501)
    laser_data.timestamp = 121212121212
    laser_data.time_increment = 10
    laser_data.angle_min = 0.1
    laser_data.angle_max = 0.9
    laser_data.angle_increment = 0.05
    laser_data.range_min = 0.1
    laser_data.range_max = 0.8
    laser_data_ptr = (c_void_p * 1)(0)
    laser_data_ptr[0] = ctypes.cast(laser_data, ctypes.c_void_p)

    state, laser_data = camera.DcSpecialControl(handle, "SetLaserData", laser_data_ptr)
    check_state(camera, state, handle)
    if len(laser_data.ranges):
        laser_data.ranges = []

    # get algo version
    state, algo_version = camera.DcGetStringValue(handle, LX_CAMERA_FEATURE.LX_STRING_ALGORITHM_VERSION)
    check_state(camera, state, handle)
    print(f'Algo version: {algo_version}')

    # get current algo param
    state, algo_param = camera.DcGetStringValue(handle, LX_CAMERA_FEATURE.LX_STRING_ALGORITHM_PARAMS)
    check_state(camera, state, handle)
    print(f'Algo param: {algo_param}')

    # import vis map
    in_map_list = ["./assets/22.pcapng"]
    state, value = camera.DcSpecialControl(handle, "ImportLocationMapFile", in_map_list[0])
    print(1)



if __name__ == '__main__':
    demo_application_location()
