import time
import os
import cv2
from LxCameraSDK import LxCamera, LX_OPEN_MODE, LX_STATE, LX_CAMERA_FEATURE, DcHandle, FrameInfo, LX_CAMERA_STATUS, CameraStatus
from LxCameraSDK.Sample.utils import check_state, visualize


def callback(state_ptr: CameraStatus):
    print("callback, state: {}, time: {}".format(state_ptr.contents.camera_state, state_ptr.contents.status_time))


def main(dll_path):
    camera = LxCamera(dll_path)

    # 搜索设备
    state, dev_list, dev_num = camera.DcGetDeviceList()
    check_state(camera, state)
    if dev_num <= 0:
        print('not found any device, exit')
        exit(1)
    print(f"DcGetDeviceList success, device num: {dev_num}")
    open_mode = LX_OPEN_MODE.OPEN_BY_IP
    if open_mode == LX_OPEN_MODE.OPEN_BY_IP:
        open_param = "192.168.100.82"
    elif open_mode == LX_OPEN_MODE.OPEN_BY_ID:
        open_param = "F131411400000000"
    elif open_mode == LX_OPEN_MODE.OPEN_BY_SN:
        open_param = "519889C9A2A6468E"
    elif open_mode == LX_OPEN_MODE.OPEN_BY_INDEX:
        open_param = "0"
    else:
        raise NotImplementedError(f"Camera open mode {open_mode} not implemented")

    # 打开设备
    state, handle, device_info = camera.DcOpenDevice(open_mode, open_param)
    if state != LX_STATE.LX_SUCCESS:
        print(f"open device failed, open_mode: {open_mode}, open_param: {open_param}, exit")
        check_state(camera, state)
        exit(1)
    print(f"DcOpenDevice success, device_info:\n"
          f"camera_id: {device_info.id}\n"
          f"unique_id: {handle}\n"
          f"camera_ip: {device_info.ip}\n"
          f"firmware_ver: {device_info.firmware_ver}\n"
          f"camera_sn: {device_info.sn}\n"
          f"camera_name: {device_info.name}\n"
          f"img_algorithm_ver: {device_info.algor_ver}")

    # 设置相机状态回调函数
    state = camera.DcRegisterCameraStatusCallback(handle, callback)
    check_state(camera, state, handle)
    print('DcRegisterCameraStatusCallback success')

    # 测试回调函数是否正常调用，如果不需要，把下面的代码注释
    for _ in range(10):
        time.sleep(1)
    state = camera.DcUnregisterCameraStatusCallback(handle)
    check_state(camera, state, handle)
    print('DcUnregisterCameraStatusCallback success')

    # 开启2D流
    enable_2d = True
    state = camera.DcSetBoolValue(handle, LX_CAMERA_FEATURE.LX_BOOL_ENABLE_2D_STREAM, enable_2d)
    check_state(camera, state, handle)
    print('DcSetBoolValue success, cmd: LX_BOOL_ENABLE_2D_STREAM')

    # 开启3D深度流
    enable_depth = True
    state = camera.DcSetBoolValue(handle, LX_CAMERA_FEATURE.LX_BOOL_ENABLE_3D_DEPTH_STREAM, enable_depth)
    check_state(camera, state, handle)
    print('DcSetBoolValue success, cmd: LX_BOOL_ENABLE_3D_DEPTH_STREAM')

    # 开启3D强度流
    enable_amp = True
    state = camera.DcSetBoolValue(handle, LX_CAMERA_FEATURE.LX_BOOL_ENABLE_3D_AMP_STREAM, enable_amp)
    check_state(camera, state, handle)
    print('DcSetBoolValue success, cmd: LX_BOOL_ENABLE_3D_AMP_STREAM')

    # 是否开启2D流
    state, get_rgb_enable = camera.DcGetBoolValue(handle, LX_CAMERA_FEATURE.LX_BOOL_ENABLE_2D_STREAM)
    check_state(camera, state, handle)
    print(f'DcGetBoolValue success, cmd: LX_BOOL_ENABLE_2D_STREAM, get_2d_enable: {get_rgb_enable}')

    # 是否开启3D深度流
    state, get_depth_enable = camera.DcGetBoolValue(handle, LX_CAMERA_FEATURE.LX_BOOL_ENABLE_3D_DEPTH_STREAM)
    check_state(camera, state, handle)
    print(f'DcGetBoolValue success, cmd: LX_BOOL_ENABLE_3D_DEPTH_STREAM, depth_enable: {get_depth_enable}')

    # 是否开启3D强度流
    state, get_amp_enable = camera.DcGetBoolValue(handle, LX_CAMERA_FEATURE.LX_BOOL_ENABLE_3D_AMP_STREAM)
    check_state(camera, state, handle)
    print(f'DcGetBoolValue success, cmd: LX_BOOL_ENABLE_2D_STREAM, amp_enable: {get_amp_enable}')

    # RGBD对齐，TOF的图像尺寸和像素会扩展到与RGB一致，开启后建议关闭强度流
    # state = camera.DcSetBoolValue(handle, LX_CAMERA_FEATURE.LX_BOOL_ENABLE_2D_TO_DEPTH, True)
    # check_state(camera, state, handle)

    # 获取图像参数，设置ROI BINNING RGBD对齐之后需要重新获取图像尺寸
    # 获取3D图像宽度
    state, value = camera.DcGetIntValue(handle, LX_CAMERA_FEATURE.LX_INT_3D_IMAGE_WIDTH)
    check_state(camera, state, handle)
    print(f'DcGetIntValue success, cmd: LX_INT_3D_IMAGE_WIDTH, value: {value.cur_value}')

    # 获取3D图像高度
    state, value = camera.DcGetIntValue(handle, LX_CAMERA_FEATURE.LX_INT_3D_IMAGE_HEIGHT)
    check_state(camera, state, handle)
    print(f'DcGetIntValue success, cmd: LX_INT_3D_IMAGE_HEIGHT, value: {value.cur_value}')

    # 获取3D深度图数据类型
    state, value = camera.DcGetIntValue(handle, LX_CAMERA_FEATURE.LX_INT_3D_DEPTH_DATA_TYPE)
    check_state(camera, state, handle)
    print(f'DcGetIntValue success, cmd: LX_INT_3D_DEPTH_DATA_TYPE, value: {value.cur_value}')

    # 获取3D强度图数据类型
    state, value = camera.DcGetIntValue(handle, LX_CAMERA_FEATURE.LX_INT_3D_AMPLITUDE_DATA_TYPE)
    check_state(camera, state, handle)
    print(f'DcGetIntValue success, cmd: LX_INT_3D_AMPLITUDE_DATA_TYPE, value: {value.cur_value}')

    # 获取2D图像宽度
    state, value = camera.DcGetIntValue(handle, LX_CAMERA_FEATURE.LX_INT_2D_IMAGE_WIDTH)
    check_state(camera, state, handle)
    print(f'DcGetIntValue success, cmd: LX_INT_2D_IMAGE_WIDTH, value: {value.cur_value}')

    # 获取2D图像高度
    state, value = camera.DcGetIntValue(handle, LX_CAMERA_FEATURE.LX_INT_2D_IMAGE_HEIGHT)
    check_state(camera, state, handle)
    print(f'DcGetIntValue success, cmd: LX_INT_2D_IMAGE_HEIGHT, value: {value.cur_value}')

    # 获取2D图像通道数
    state, value = camera.DcGetIntValue(handle, LX_CAMERA_FEATURE.LX_INT_2D_IMAGE_CHANNEL)
    check_state(camera, state, handle)
    print(f'DcGetIntValue success, cmd: LX_INT_2D_IMAGE_CHANNEL, value: {value.cur_value}')

    # 可以根据需要, 是否开启帧同步模式, 开启该模式, 内部会对每一帧做同步处理后返回
    # 默认若不需要tof与rgb数据同步, 则不需要开启此功能, 内部会优先保证数据实时性
    # state = camera.DcSetBoolValue(handle, LX_CAMERA_FEATURE.LX_BOOL_ENABLE_SYNC_FRAME, False)
    # check_state(camera, state, handle)
    # print('DcSetBoolValue success, cmd: LX_BOOL_ENABLE_SYNC_FRAME, set to False')

    # 开启数据流
    state = camera.DcStartStream(handle)
    check_state(camera, state, handle)
    print('DcStartStream success')

    # 获取点云，需先设置指令LX_CMD_GET_NEW_FRAME
    state = camera.DcSetCmd(handle, LX_CAMERA_FEATURE.LX_CMD_GET_NEW_FRAME)
    check_state(camera, state, handle)
    state, points = camera.getPointCloud(handle)
    check_state(camera, state, handle)
    try:
        import open3d as o3d
        pc = o3d.geometry.PointCloud()
        pc.points = o3d.utility.Vector3dVector(points.reshape(-1, 3))
        o3d.visualization.draw_geometries([pc])
    except:
        print("please install open3d via pip first")

    time1 = time.time()
    while True:
        # 更新数据
        state, frame_data_ptr = camera.getFrame(handle)
        if state != LX_STATE.LX_SUCCESS and state != LX_STATE.LX_E_FRAME_ID_NOT_MATCH and state != LX_STATE.LX_E_FRAME_MULTI_MACHINE:
            if state == LX_STATE.LX_E_RECONNECTING:
                print('device reconnecting')
                time.sleep(1)
                continue
        # 获取点云，由于camera.getFrame()已经设置指令LX_CAMERA_FEATURE.LX_CMD_GET_NEW_FRAME，所以可直接获取
        state, points = camera.getPointCloud(handle)
        check_state(camera, state, handle)
        try:
            import open3d as o3d
            pc = o3d.geometry.PointCloud()
            pc.points = o3d.utility.Vector3dVector(points.reshape(-1, 3))
            o3d.visualization.draw_geometries([pc])
        except:
            print("please install open3d via pip first")
        # 帧率
        time2 = time.time()
        if (time2 - time1) > 1:
            time1 = time.time()
            fps_str = ""
            if get_depth_enable:
                state, depth_fps = camera.DcGetFloatValue(handle, LX_CAMERA_FEATURE.LX_FLOAT_3D_DEPTH_FPS)
                check_state(camera, state, handle)
                fps_str += f'depth fps: {depth_fps.cur_value}'
            if get_rgb_enable:
                state, rgb_fps = camera.DcGetFloatValue(handle, LX_CAMERA_FEATURE.LX_FLOAT_2D_IMAGE_FPS)
                check_state(camera, state, handle)
                fps_str += f', rgb fps: {rgb_fps.cur_value}'
            print(fps_str)
        # 显示深度图
        if get_depth_enable:
            state, depth_image = camera.getDepthImage(frame_data_ptr)
            check_state(camera, state, handle)
            print(f'getDepthImage success, depth_img.shape: {depth_image.shape}, value of (100, 100): {depth_image[100, 100]}')
            cv2.namedWindow("depth", 0)
            cv2.resizeWindow("depth", 640, 480)
            cv2.imshow("depth", visualize(depth_image))
            cv2.waitKey(10)

        # 显示强度图
        if get_amp_enable:
            state, amp_image = camera.getAmpImage(frame_data_ptr)
            check_state(camera, state, handle)
            print(f'getAmpImage success, amp_image.shape: {amp_image.shape}, value of (100, 100): {amp_image[100, 100]}')
            cv2.namedWindow("amp", 0)
            cv2.resizeWindow("amp", 640, 480)
            cv2.imshow("amp", visualize(amp_image))
            cv2.waitKey(10)
        # 显示RGB图
        if get_rgb_enable:
            state, rgb_image = camera.getRGBImage(frame_data_ptr)
            check_state(camera, state, handle)
            print(f'getRGBImage success, rgb_image.shape: {rgb_image.shape}, value of (100, 100): {rgb_image[100, 100]}')
            cv2.namedWindow("rgb", 0)
            cv2.resizeWindow("rgb", 640, 480)
            cv2.imshow("rgb", rgb_image)
            cv2.waitKey(10)


if __name__ == '__main__':
    main("libLxCameraApi.so")
