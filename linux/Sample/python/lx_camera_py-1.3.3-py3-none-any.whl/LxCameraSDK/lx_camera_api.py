import os
from enum import Enum
from typing import Tuple, Any, Callable
import sys
from LxCameraSDK.lx_camera_define import (DcHandle, LX_STATE, LxDeviceInfo, LxIntValueInfo, LxFloatValueInfo,
                                          LX_OPEN_MODE, LX_CAMERA_FEATURE, Image3DExtricParam, ImageIntricParam,
                                          FrameInfo, LX_ALGORITHM_MODE, LX_CAMERA_STATUS_CALLBACK, LX_DATA_TYPE_TO_CTYPES, LX_DATA_TYPE)
from LxCameraSDK.lx_camera_application import LxAvoidanceOutput, LxPalletPose, LxLocation, LxAvoidanceOutputN
import ctypes
from ctypes import CDLL, c_char_p, create_string_buffer, byref, c_int, c_bool, POINTER, c_float, c_void_p
import numpy as np


SDK_VERSION = "2.4.30"


def status_callback(status_ptr):
    status = status_ptr.contents
    print(status.camera_state, status.status_time)


class LxCamera:
    def __init__(self, dll_path: str):
        assert os.path.isfile(dll_path), f"file {dll_path} does not exist"
        if sys.platform.startswith('win'):
            suffix = '.dll'
        elif sys.platform.startswith('linux'):
            suffix = '.so'
        else:
            raise NotImplementedError("Unsupported platform")
        assert dll_path.endswith(suffix), f"Your platform: {sys.platform}, please provide a valid {suffix} path"
        self.__status_dict = {}
        self._dll = CDLL(dll_path)
        self._init_c_func()
        self._check_version()

    def _init_c_func(self):
        self._dll.DcGetApiVersion.restype = c_char_p

        self._dll.DcSetInfoOutput.argtypes = [c_int, c_bool, c_char_p, c_int]
        self._dll.DcSetInfoOutput.restype = LX_STATE

        self._dll.DcLog.argtypes = [c_char_p]
        self._dll.DcLog.restype = LX_STATE

        self._dll.DcGetDeviceList.argtypes = [POINTER(POINTER(LxDeviceInfo)), POINTER(c_int)]
        self._dll.DcGetDeviceList.restype = LX_STATE

        self._dll.DcOpenDevice.argtypes = [c_int, c_char_p, POINTER(DcHandle), POINTER(LxDeviceInfo)]
        self._dll.DcOpenDevice.restype = LX_STATE

        self._dll.DcCloseDevice.argtypes = [DcHandle]
        self._dll.DcCloseDevice.restype = LX_STATE

        self._dll.DcStartStream.argtypes = [DcHandle]
        self._dll.DcStartStream.restype = LX_STATE

        self._dll.DcStopStream.argtypes = [DcHandle]
        self._dll.DcStopStream.restype = LX_STATE

        self._dll.DcSaveXYZ.argtypes = [DcHandle, c_char_p]
        self._dll.DcSaveXYZ.restype = LX_STATE

        self._dll.DcSetCameraIp.argtypes = [DcHandle, c_char_p, c_char_p, c_char_p]
        self._dll.DcSetCameraIp.restype = LX_STATE

        self._dll.DcSetIntValue.argtypes = [DcHandle, c_int, c_int]
        self._dll.DcSetIntValue.restype = LX_STATE

        self._dll.DcGetIntValue.argtypes = [DcHandle, c_int, POINTER(LxIntValueInfo)]
        self._dll.DcGetIntValue.restype = LX_STATE

        self._dll.DcSetFloatValue.argtypes = [DcHandle, c_int, c_float]
        self._dll.DcSetFloatValue.restype = LX_STATE

        self._dll.DcGetFloatValue.argtypes = [DcHandle, c_int, POINTER(LxFloatValueInfo)]
        self._dll.DcGetFloatValue.restype = LX_STATE

        self._dll.DcSetBoolValue.argtypes = [DcHandle, c_int, c_bool]
        self._dll.DcSetBoolValue.restype = LX_STATE

        self._dll.DcGetBoolValue.argtypes = [DcHandle, c_int, POINTER(c_bool)]
        self._dll.DcGetBoolValue.restype = LX_STATE

        self._dll.DcSetStringValue.argtypes = [DcHandle, c_int, c_char_p]
        self._dll.DcSetStringValue.restype = LX_STATE

        self._dll.DcGetStringValue.argtypes = [DcHandle, c_int, POINTER(c_char_p)]
        self._dll.DcGetStringValue.restype = LX_STATE

        # self._dll.DcGetPtrValue.argtypes = [DcHandle, c_int, POINTER(c_void_p)]
        self._dll.DcGetPtrValue.restype = LX_STATE

        self._dll.DcSetCmd.argtypes = [DcHandle, c_int]
        self._dll.DcSetCmd.restype = LX_STATE

        self._dll.DcSpecialControl.argtypes = [DcHandle, c_char_p, c_void_p]
        self._dll.DcSpecialControl.restype = LX_STATE

        self._dll.DcSetROI.argtypes = [DcHandle, c_int, c_int, c_int, c_int, c_int]
        self._dll.DcSetROI.restype = LX_STATE

        self._dll.DcGetErrorString.argtypes = [c_int]
        self._dll.DcGetErrorString.restype = c_char_p

        self._dll.DcRegisterCameraStatusCallback.argtypes = [DcHandle, LX_CAMERA_STATUS_CALLBACK, c_void_p]
        self._dll.DcRegisterCameraStatusCallback.restype = LX_STATE

        self._dll.DcUnregisterCameraStatusCallback.argtypes = [DcHandle]
        self._dll.DcUnregisterCameraStatusCallback.restype = LX_STATE

    def _check_version(self):
        load_version = self.DcGetApiVersion()
        if load_version <= SDK_VERSION:
            self.DcLog(f"SDK version mismatch, SDK_VERSION: {SDK_VERSION}, load version: {load_version}, may result in undefined behavior")
            print(f"SDK version mismatch, SDK_VERSION: {SDK_VERSION}, load version: {load_version}, may result in undefined behavior")

    @staticmethod
    def _gen_c_string(string: str):  # const char*
        return create_string_buffer(string.encode('utf-8'))

    def DcGetApiVersion(self) -> str:
        return self._dll.DcGetApiVersion().decode('utf-8')

    def DcSetInfoOutput(self, print_level: int, enable_screen_print: bool, log_path: str, language: int = 0) -> LX_STATE:
        """
        Set the level of log
        :param print_level: print_level 0: info All debug messages 1: warn Important and warning debug messages 2: error Only error messages are output.
        :param enable_screen_print: Whether to print in the window
        :param log_path: Log file save path
        :param language: language
        :return: LX_STATE
        """
        return self._dll.DcSetInfoOutput(
            print_level,
            enable_screen_print,
            self._gen_c_string(log_path),
            language
        )

    def DcLog(self, string: str) -> LX_STATE:
        """
        Allows users to output debugging information to log files.
        :param string: String to be output, ending with '\0'.
        :return: LX_STATE
        """
        return self._dll.DcLog(self._gen_c_string(string))

    def DcGetDeviceList(self) -> Tuple[LX_STATE, POINTER, int]:
        """
        Search for camera list
        :return: LX_STATE, dev_list, dev_num
        """
        dev_list = POINTER(LxDeviceInfo)()
        dev_num = c_int()
        ret = self._dll.DcGetDeviceList(byref(dev_list), byref(dev_num))
        return ret, dev_list, dev_num.value

    def DcOpenDevice(self, open_mode: LX_OPEN_MODE, param: str) -> Tuple[LX_STATE, DcHandle, LxDeviceInfo]:
        """
        Open device
        :param open_mode: Open mode, see LX_OPEN_MODE for details.
        :param param: Fill in different parameters for different opening methods (when the sdk is running inside the camera, fill in "127.0.0.1" here)
        :return: [LX_STATE, DcHandle, LxDeviceInfo]
        """
        assert isinstance(open_mode, LX_OPEN_MODE), f'Direct use of bare OPEN_MODE is not supported, see LX_OPEN_MODE for details'
        handle = DcHandle()
        device_info = LxDeviceInfo()
        ret = self._dll.DcOpenDevice(
            open_mode.value,
            self._gen_c_string(param),
            byref(handle),
            byref(device_info)
        )
        return ret, handle, device_info

    def DcCloseDevice(self, handle: DcHandle) -> LX_STATE:
        """
        Close device
        :param handle: Device handle
        :return: LX_STATE
        """
        return self._dll.DcCloseDevice(handle)

    def DcStartStream(self, handle: DcHandle) -> LX_STATE:
        """
        Start stream data
        :param handle: Device handle
        :return: LX_STATE
        """
        return self._dll.DcStartStream(handle)

    def DcStopStream(self, handle: DcHandle) -> LX_STATE:
        """
        stop stream data
        :param handle: Device handle
        :return: LX_STATE
        """
        return self._dll.DcStopStream(handle)

    def DcSaveXYZ(self, handle: DcHandle, filename: str) -> LX_STATE:
        """
        Save the point cloud, which can be called directly
        :param handle: Device handle
        :param filename: File name, supports txt, ply and pcd formats. txt format saves all data in image order, ply and pcd only save non-zero data
        :return: LX_STATE
        """
        return self._dll.DcSaveXYZ(handle, filename.encode('utf-8'))

    def DcSetCameraIp(self, handle: DcHandle, ip: str, netmask: str = "", gateway: str = "") -> LX_STATE:
        """
        Set camera IP-related parameters, the camera will automatically reboot when the setup is complete
        :param handle: Device handle
        :param ip: Device IP
        :param netmask: Subnet Mask (if empty, internal default is "255.255.0.0")
        :param gateway: gateway ip (if pass empty, internal default will set the last segment of ip to "1" as gateway)
        :return: LX_STATE
        """
        return self._dll.DcSetCameraIp(
            handle,
            self._gen_c_string(ip),
            self._gen_c_string(netmask) if netmask else b'',
            self._gen_c_string(gateway) if gateway else b''
        )

    def DcSetIntValue(self, handle: DcHandle, cmd: LX_CAMERA_FEATURE, value: Any) -> LX_STATE:
        """
        Set int type parameters
        :param handle: Device handle
        :param cmd: Reference LX_CAMERA_FEATURE
        :param value: Setting parameter values
        :return: LX_STATE
        """
        if isinstance(value, Enum):
            value = value.value
        assert isinstance(cmd, LX_CAMERA_FEATURE), f'Direct use of bare commands is not supported, see LX_CAMERA_FEATURE for details'
        return self._dll.DcSetIntValue(handle, cmd.value, value)

    def DcGetIntValue(self, handle: DcHandle, cmd: LX_CAMERA_FEATURE) -> Tuple[LX_STATE, LxIntValueInfo]:
        """
        Obtain int type parameters
        :param handle: Device handle
        :param cmd: Reference LX_CAMERA_FEATURE
        :return: LX_STATE, LxIntValueInfo
        """
        assert isinstance(cmd, LX_CAMERA_FEATURE), f'Direct use of bare commands is not supported, see LX_CAMERA_FEATURE for details'
        value = LxIntValueInfo()
        ret = self._dll.DcGetIntValue(
            handle,
            cmd.value,
            byref(value)
        )
        return ret, value

    def DcSetFloatValue(self, handle: DcHandle, cmd: LX_CAMERA_FEATURE, value: float) -> LX_STATE:
        """
        Set float type parameters
        :param handle: Device handle
        :param cmd: Reference LX_CAMERA_FEATURE
        :param value: Setting parameter values
        :return: LX_STATE
        """
        assert isinstance(cmd, LX_CAMERA_FEATURE), f'Direct use of bare commands is not supported, see LX_CAMERA_FEATURE for details'
        return self._dll.DcSetFloatValue(handle, cmd.value, value)

    def DcGetFloatValue(self, handle: DcHandle, cmd: LX_CAMERA_FEATURE) -> Tuple[LX_STATE, LxFloatValueInfo]:
        """
        Obtain float type parameters
        :param handle: Device handle
        :param cmd: Reference LX_CAMERA_FEATURE
        :return: LX_STATE, LxFloatValueInfo
        """
        assert isinstance(cmd, LX_CAMERA_FEATURE), f'Direct use of bare commands is not supported, see LX_CAMERA_FEATURE for details'
        value = LxFloatValueInfo()
        ret = self._dll.DcGetFloatValue(
            handle,
            cmd.value,
            byref(value)
        )
        return ret, value

    def DcSetBoolValue(self, handle: DcHandle, cmd: LX_CAMERA_FEATURE, value: bool) -> LX_STATE:
        assert isinstance(cmd, LX_CAMERA_FEATURE), f'Direct use of bare commands is not supported, see LX_CAMERA_FEATURE for details'
        return self._dll.DcSetBoolValue(
            handle,
            cmd.value,
            value
        )

    def DcGetBoolValue(self, handle: DcHandle, cmd: LX_CAMERA_FEATURE) -> Tuple[LX_STATE, bool]:
        """
        Obtain bool type parameters
        :param handle: Device handle
        :param cmd: Reference LX_CAMERA_FEATURE
        :return: LX_STATE, bool
        """
        assert isinstance(cmd, LX_CAMERA_FEATURE), f'Direct use of bare commands is not supported, see LX_CAMERA_FEATURE for details'
        value = c_bool(True)
        ret = self._dll.DcGetBoolValue(
            handle,
            cmd.value,
            byref(value)
        )
        return ret, value.value

    def DcSetStringValue(self, handle: DcHandle, cmd: LX_CAMERA_FEATURE, value: str) -> LX_STATE:
        """
        Set string type parameters
        :param handle: Device handle
        :param cmd: Reference LX_CAMERA_FEATURE
        :param value:
        :return: LX_STATE
        """
        assert isinstance(cmd, LX_CAMERA_FEATURE), f'Direct use of bare commands is not supported, see LX_CAMERA_FEATURE for details'
        return self._dll.DcSetStringValue(
            handle,
            cmd.value,
            self._gen_c_string(value)
        )

    def DcGetStringValue(self, handle: DcHandle, cmd: LX_CAMERA_FEATURE) -> Tuple[LX_STATE, str]:
        """
        Obtain string type parameters
        :param handle: Device handle
        :param cmd: Reference LX_CAMERA_FEATURE
        :return: LX_STATE, str
        """
        assert isinstance(cmd, LX_CAMERA_FEATURE), f'Direct use of bare commands is not supported, see LX_CAMERA_FEATURE for details'
        value_ptr = c_char_p()  # nullptr
        ret = self._dll.DcGetStringValue(
            handle,
            cmd.value,
            byref(value_ptr)
        )
        if ret == LX_STATE.LX_SUCCESS:
            return ret, value_ptr.value.decode('utf-8')
        return ret, ""

    def _DcGetPtrValue(self, handle: DcHandle, cmd: LX_CAMERA_FEATURE) -> Tuple[LX_STATE, Any]:
        """
        Obtain pointer type parameters
        :param handle: Device handle
        :param cmd: Reference LX_CAMERA_FEATURE
        :return: LX_STATE, data_ptr
        """
        assert isinstance(cmd, LX_CAMERA_FEATURE), f'Direct use of bare commands is not supported, see LX_CAMERA_FEATURE for details'
        if cmd == LX_CAMERA_FEATURE.LX_PTR_2D_INTRIC_PARAM:
            result_handle = POINTER(ImageIntricParam)()
        elif cmd == LX_CAMERA_FEATURE.LX_PTR_3D_INTRIC_PARAM:
            result_handle = POINTER(ImageIntricParam)()
        elif cmd == LX_CAMERA_FEATURE.LX_PTR_3D_EXTRIC_PARAM:
            result_handle = POINTER(Image3DExtricParam)()
        elif cmd in [
            LX_CAMERA_FEATURE.LX_PTR_2D_IMAGE_DATA,
            LX_CAMERA_FEATURE.LX_PTR_3D_AMP_DATA,
            LX_CAMERA_FEATURE.LX_PTR_3D_DEPTH_DATA,
            # LX_CAMERA_FEATURE.LX_PTR_XYZ_DATA,
            LX_CAMERA_FEATURE.LX_PTR_FRAME_DATA
        ]:
            result_handle = POINTER(FrameInfo)()
        elif cmd == LX_CAMERA_FEATURE.LX_PTR_ALGORITHM_OUTPUT:
            ret_code, algorithm_mode_value = self.DcGetIntValue(handle, LX_CAMERA_FEATURE.LX_INT_ALGORITHM_MODE)
            if ret_code != LX_STATE.LX_SUCCESS:
                return ret_code, None
            algorithm_mode = LX_ALGORITHM_MODE(algorithm_mode_value.cur_value)
            if algorithm_mode == LX_ALGORITHM_MODE.MODE_AVOID_OBSTACLE:
                result_handle = POINTER(LxAvoidanceOutput)()
            elif algorithm_mode == LX_ALGORITHM_MODE.MODE_PALLET_LOCATE:
                result_handle = POINTER(LxPalletPose)()
            elif algorithm_mode == LX_ALGORITHM_MODE.MODE_VISION_LOCATION:
                result_handle = POINTER(LxLocation)()
            elif algorithm_mode == LX_ALGORITHM_MODE.MODE_AVOID_OBSTACLE2:
                result_handle = POINTER(LxAvoidanceOutputN)()
            else:
                raise NotImplementedError(f'Unsupported algorithm mode: {algorithm_mode}')
        else:
            raise NotImplementedError(f'Unsupported command: {cmd}')
        ret_code = self._dll.DcGetPtrValue(handle, cmd.value, byref(result_handle))
        result = result_handle.contents if result_handle else None
        return ret_code, result

    def get2DIntricParam(self, handle: DcHandle) -> Tuple[LX_STATE, Any, Any]:
        """
        Get 2D camera intrinsic param
        :param handle: device handle
        :return: LX_STATE, intrinsic, distort
        """
        return self._getIntricParam(handle, LX_CAMERA_FEATURE.LX_PTR_2D_INTRIC_PARAM)

    def get3DIntricParam(self, handle: DcHandle) -> Tuple[LX_STATE, Any, Any]:
        """
        Get 3D camera intrinsic param
        :param handle: device handle
        :return: LX_STATE, intrinsic[fx, fy, cx, cy], distort[d1, d2, d3, d4, d5]
        """
        return self._getIntricParam(handle, LX_CAMERA_FEATURE.LX_PTR_3D_INTRIC_PARAM)

    def get3DTransMatrix(self, handle) -> Tuple[LX_STATE, Any]:
        """
        Get 3D camera translation matrix,
        :param handle: device handle
        :return: 4x3 translation matrix, first 3x3 is rotation matrix, last column is translation vector
        """
        result_handle = POINTER(Image3DExtricParam)()
        ret_code = self._dll.DcGetPtrValue(handle, LX_CAMERA_FEATURE.LX_PTR_3D_EXTRIC_PARAM.value, byref(result_handle))
        ret_value = None
        if ret_code == LX_STATE.LX_SUCCESS:
            raw_param = result_handle.contents
            ret_value = np.zeros([3, 4], dtype=np.float32)
            ret_value[0][0] = raw_param.r0
            ret_value[0][1] = raw_param.r1
            ret_value[0][2] = raw_param.r2
            ret_value[1][0] = raw_param.r3
            ret_value[1][1] = raw_param.r4
            ret_value[1][2] = raw_param.r5
            ret_value[2][0] = raw_param.r6
            ret_value[2][1] = raw_param.r7
            ret_value[2][2] = raw_param.r8
            ret_value[0][3] = raw_param.t0
            ret_value[1][3] = raw_param.t1
            ret_value[2][3] = raw_param.t2
        return ret_code, ret_value

    def _getIntricParam(self, handle: DcHandle, cmd: LX_CAMERA_FEATURE):
        result_handle = POINTER(ImageIntricParam)()
        ret = self._dll.DcGetPtrValue(handle, cmd.value, byref(result_handle))
        if ret == LX_STATE.LX_SUCCESS:
            raw_param = result_handle.contents
            intrinsic = [raw_param.fx, raw_param.fy, raw_param.cx, raw_param.cy]
            distort = [raw_param.d1, raw_param.d2, raw_param.d3, raw_param.d4, raw_param.d5]
            return ret, intrinsic, distort
        return ret, None, None

    def getFrame(self, handle: DcHandle) -> Tuple[LX_STATE, Any]:
        """
        Get a new frame
        :param handle: Device handle
        :return: LX_STATE, frame_data_ptr
        """
        ret = self.DcSetCmd(handle, LX_CAMERA_FEATURE.LX_CMD_GET_NEW_FRAME)
        if ret == LX_STATE.LX_SUCCESS:
            return self._DcGetPtrValue(handle, LX_CAMERA_FEATURE.LX_PTR_FRAME_DATA)
        return ret, None

    def getRGBImage(self, data_ptr: FrameInfo) -> Tuple[LX_STATE, Any]:
        """
        Obtain rgb image
        :param data_ptr: FrameDataInfo type
        :return: LX_STATE, rgb_image
        """
        return self._getImageData(data_ptr, 'rgb_data')

    def getAmpImage(self, data_ptr: FrameInfo) -> Tuple[LX_STATE, Any]:
        return self._getImageData(data_ptr, 'amp_data')

    def getDepthImage(self, data_ptr: FrameInfo) -> Tuple[LX_STATE, Any]:
        return self._getImageData(data_ptr, 'depth_data')

    def getPointCloud(self, handle: DcHandle) -> Tuple[LX_STATE, Any]:
        """
        Get point cloud data, device must have LX_BOOL_ENABLE_3D_DEPTH_STREAM turned on.
        :param handle: device handle
        :return: LX_STATE, points[depth_width, depth_height, 3]
        """
        if not self.DcGetBoolValue(handle, LX_CAMERA_FEATURE.LX_BOOL_ENABLE_3D_DEPTH_STREAM):
            return LX_STATE.LX_E_NOT_RECEIVE_STREAM, None
        state, depth_height = self.DcGetIntValue(handle, LX_CAMERA_FEATURE.LX_INT_3D_IMAGE_HEIGHT)
        depth_height = depth_height.cur_value
        if state != LX_STATE.LX_SUCCESS:
            return state, None
        state, depth_width = self.DcGetIntValue(handle, LX_CAMERA_FEATURE.LX_INT_3D_IMAGE_WIDTH)
        depth_width = depth_width.cur_value
        if state != LX_STATE.LX_SUCCESS:
            return state, None
        data_ptr = POINTER(c_float * depth_height * depth_width * 3)()
        state = self._dll.DcGetPtrValue(handle, LX_CAMERA_FEATURE.LX_PTR_XYZ_DATA.value, byref(data_ptr))
        if state != LX_STATE.LX_SUCCESS:
            return state, None
        points = np.array(data_ptr.contents, dtype=np.float32).reshape((depth_height, depth_width, 3))
        return state, points

    def _getImageData(self, data_ptr: FrameInfo, tgt_data: str) -> Tuple[LX_STATE, Any]:
        """
        Get the specified data
        :param data_ptr: pointer of FrameDataInfo
        :param tgt_data:
        :return: LX_STATE, image_data
        """
        if not hasattr(data_ptr, tgt_data):
            return LX_STATE.LX_ERROR, None
        tgt_ptr = getattr(data_ptr, tgt_data)
        if not tgt_ptr.frame_data:
            return LX_STATE.LX_ERROR, None
        width = tgt_ptr.frame_width
        height = tgt_ptr.frame_height
        channel = tgt_ptr.frame_channel
        data_type = LX_DATA_TYPE_TO_CTYPES[LX_DATA_TYPE(tgt_ptr.frame_data_type)]
        if tgt_data == 'rgb_data':
            return LX_STATE.LX_SUCCESS, np.ctypeslib.as_array((data_type * (width * height * channel)).from_address(tgt_ptr.frame_data)).reshape((height, width, channel))
        elif tgt_data == 'amp_data':
            return LX_STATE.LX_SUCCESS, np.ctypeslib.as_array((data_type * (width * height)).from_address(tgt_ptr.frame_data)).reshape((height, width))
        elif tgt_data == 'depth_data':
            return LX_STATE.LX_SUCCESS, np.ctypeslib.as_array((data_type * (width * height)).from_address(tgt_ptr.frame_data)).reshape((height, width))
        else:
            raise NotImplementedError(f'Unsupported data type: {tgt_data}')

    def DcSetCmd(self, handle: DcHandle, cmd: LX_CAMERA_FEATURE) -> LX_STATE:
        """
        Execute the corresponding CMD type command
        :param handle: Device handle
        :param cmd: Reference LX_CAMERA_FEATURE
        :return: LX_STATE
        """
        assert isinstance(cmd, LX_CAMERA_FEATURE), f'Direct use of bare commands is not supported, see LX_CAMERA_FEATURE for details'
        return self._dll.DcSetCmd(handle, cmd.value)

    def DcSpecialControl(self, handle: DcHandle, command: str, value: ctypes.c_void_p=None) -> Tuple[LX_STATE, Any]:
        """
        Special operations outside the definition of LX_CAMERA_FEATURE, with specific functions and parameters defined by the string command
        :param handle: Device handle
        :param command: Command
        :return: LX_STATE, value_ptr.value
        """
        if value is None:
            value_ptr = c_void_p()
        else:
            value_ptr = c_void_p(value)
        ret = self._dll.DcSpecialControl(handle, self._gen_c_string(command), byref(value_ptr))
        if value_ptr.value is None and command == "GetObstacleIO":
            return ret, 0
        return ret, value_ptr.value

    def DcSetRoI(self, handle: DcHandle, offset_x: int, offset_y: int, width: int, height: int, img_type: int) -> LX_STATE:
        """

        :param handle: Device handle
        :param offset_x: Horizontal offset of the start point in pixels
        :param offset_y: Start Point Vertical Offset Parameter
        :param width: The width of the roi target area
        :param height: The height of the roi target area
        :param img_type: 0-3D image 1-2D image
        :return: LX_STATE
        """
        return self._dll.DcSetRoI(
            handle,
            offset_x,
            offset_y,
            width,
            height,
            img_type
        )

    def getAlgorithmStatus(self, handle: DcHandle) -> Tuple[LX_STATE, Any]:
        """
        Get obstacle status V2
        :param handle: device handle
        :return: LxAvoidanceOutputN
        """
        return self._DcGetPtrValue(handle, LX_CAMERA_FEATURE.LX_PTR_ALGORITHM_OUTPUT)

    def DcGetErrorString(self, state: LX_STATE) -> str:
        """
        Get the description of the function's return status
        :param state: The status returned by the function interface
        :return: LX_API_STR
        """
        assert isinstance(state, LX_STATE), f"state must be LX_STATE, not {type(state)}"
        return self._dll.DcGetErrorString(state.value).decode('utf-8')

    def DcRegisterCameraStatusCallback(self, handle: DcHandle, func: Callable) -> LX_STATE:
        """
        Register the camera state callback function and call it automatically when the camera state changes.
        :param handle: device handle
        :param func: Callback function pointer
        :return: LX_STATE
        """
        callback = LX_CAMERA_STATUS_CALLBACK(func)
        reserve_data = c_void_p()
        res = self._dll.DcRegisterCameraStatusCallback(handle, callback, reserve_data)
        return res

    def DcUnregisterCameraStatusCallback(self, handle: DcHandle) -> LX_STATE:
        """
        Cancel camera state registration callback function
        :param handle: device handle
        :return: LX_STATE
        """
        return self._dll.DcUnregisterCameraStatusCallback(handle)
